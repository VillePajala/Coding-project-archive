import React from 'react';
import './Footer.css';
import Container from 'react-bootstrap/Container'

const Footer: React.FC = () => {
    return (
      <Container>
          <p>VIlle Pajala</p>
      </Container>
    );
  }
  
  export default Footer;